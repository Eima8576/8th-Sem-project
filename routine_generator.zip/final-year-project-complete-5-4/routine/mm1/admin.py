from django.contrib import admin
from.models import *



admin.site.register(Instructor)
admin.site.register(MeetingTime)
admin.site.register(ComputerCourse)
admin.site.register(ComputerSemester)
admin.site.register(ElectronicsCourse)
admin.site.register(ElectronicsSemester)
admin.site.register(Selectsemester)
admin.site.register(FixedClassComputer)

